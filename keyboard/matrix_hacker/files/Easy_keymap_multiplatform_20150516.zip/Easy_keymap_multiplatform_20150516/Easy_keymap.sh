#!/bin/sh

python $( cd "$( dirname "$0" )" && pwd )/main.py
